<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TaskController;
use App\Http\Middleware\AuthMiddleware;
use Illuminate\Support\Facades\Route;

// Auth Routes
Route::get('/register', [AuthController::class, 'register'])->name('register');
Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::get('/otp-verify/{email}', [AuthController::class, 'otpVerify'])->name('otpVerify');
Route::post('/otp-verify', [AuthController::class, 'registerUser'])->name('registerUser');
Route::post('/check-mail', [AuthController::class, 'sendOtp'])->name('sendOtp');
Route::post('/email-available', [AuthController::class, 'emailAvailable'])->name('emailAvailable');
Route::post('/login', [AuthController::class, 'loginUser'])->name('loginUser');


Route::middleware([AuthMiddleware::class])->group(function () {

    // Auth Routes
    Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

    // Dashboard Routes
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // Task Routes
    Route::get('/tasks', [TaskController::class, 'index'])->name('taskList');
    Route::get('/task-crud/{taskId}', [TaskController::class, 'taskCrud'])->name('taskCrud');
    Route::post('/create-task', [TaskController::class, 'createTask'])->name('createTask');
    Route::post('/update-task', [TaskController::class, 'updateTask'])->name('updateTask');
    Route::delete('/delete-task/{taskId}', [TaskController::class, 'deleteTask'])->name('deleteTask');
    Route::post('/change-task-status', [TaskController::class, 'changeTaskStatus'])->name('changeTaskStatus');
    Route::get('task-comments/{taskId}', [TaskController::class, 'taskComments'])->name('taskComments');
    Route::post('add-task-comments/{taskId}', [TaskController::class, 'addTaskComments'])->name('addTaskComments');

});

