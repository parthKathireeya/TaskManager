@extends('layouts.app')

@section('content')
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center">
            <h4>Task List</h4>
            <button class="btn btn-primary m-4" onclick="addEditTask()" id="addTaskBtn">
                <i class="fas fa-plus"></i> Add Task
            </button>
        </div>

        <table id="taskTable" class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    @if (auth()->user()->is_admin == 1)
                        <th>Assign</th>
                    @endif
                    <th>Task</th>
                    <th>Description</th>
                    <th>Due Date</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>

    <div id="taskCrudModel" class="model"></div>

@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            let table = $('#taskTable').DataTable({
                responsive: true,
                processing: true,
                serverSide: true,
                ajax: `{{ route('taskList') }}`,
                columns: [{
                        data: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    @if (auth()->user()->is_admin == 1)
                        {
                            data: 'assigned_user',
                            name: 'assigned_user',
                            render: function(data, type, row) {
                                return row.assigned_user ? row.assigned_user : 'Not Assigned';
                            }
                        },
                    @endif {
                        data: 'title',
                        name: 'title'
                    },
                    {
                        data: 'description',
                        name: 'description'
                    },
                    {
                        data: 'due_date',
                        name: 'due_date'
                    },
                    {
                        data: 'priority',
                        name: 'priority',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'status',
                        name: 'status',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });
        });

        function addEditTask(id = 0) {
            $.ajax({
                url: `task-crud/${id}`,
                type: 'GET',
                success: function(response) {

                    $('#taskModal').remove();
                    $('body').append(response);
                    $('#taskModal').modal('show');
                },
                error: function(xhr) {
                    toastr.error("Something went wrong!");
                }
            });
        }

        function deleteTask(id) {
            if (confirm("Are you sure you want to delete this task?")) {
                $.ajax({
                    url: `delete-task/${id}`,
                    type: 'DELETE',
                    data: {
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        $('#taskTable').DataTable().ajax.reload();
                        toastr.success("Task deleted successfully!");
                    },
                    error: function(xhr) {
                        toastr.error("Something went wrong!");
                    }
                });
            }
        }

        function changeStatus(id, status) {
            $.ajax({
                url: `change-task-status`,
                type: 'post',
                data: {
                    task_id: id,
                    status: status,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    $('#taskTable').DataTable().ajax.reload();
                    toastr.success("Task status updated successfully!");
                },
                error: function(xhr) {
                    toastr.error("Something went wrong!");
                }
            });
        }

        function seeComments(id) {
            $.ajax({
                url: `task-comments/${id}`,
                type: 'GET',
                success: function(response) {
                    // Remove any existing modal
                    $('#taskCommentsModal').remove();

                    // Append new modal to body
                    $('body').append(response);

                    // Ensure the modal is properly initialized
                    setTimeout(function() {
                        $('#taskCommentsModal').modal('show');
                    }, 200);
                },
                error: function(xhr) {
                    toastr.error("Something went wrong!");
                }
            });
        }
    </script>
@endsection
