@extends('layouts.fullpage')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4">
            <h2>Log in</h2>
            <form id="login-form" method="POST" action="{{ route('loginUser') }}">
                @csrf
                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="{{ old('email') }}" required>
                </div>
                <div class="mb-3">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" value="{{ old('password') }}" required pattern="[A-Za-z0-9]{8,15}">
                </div>
                <button type="submit" class="btn btn-primary w-100" id="log-in">Log in</button>
                <a href="{{ route('register') }}" class="">Register</a>
            </form>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {

            $("#login-form").validate({
                rules: {
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        minlength: 8,
                        maxlength: 15,
                        customPattern: true
                    }
                },
                messages: {
                    email: {
                        required: "Please enter a valid email address",
                        email: "Please enter a valid email address"
                    },
                    password: {
                        required: "Please enter a password",
                        minlength: "Password must be between 8 to 15 characters",
                        maxlength: "Password cannot be more than 15 characters",
                        customPattern: "Password can only contain letters and numbers"
                    }
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });

            $.validator.addMethod("customPattern", function(value, element) {
                return this.optional(element) || /^[A-Za-z0-9]+$/.test(value);
            }, "Password can only contain letters and numbers");
        });
    </script>
@endsection
