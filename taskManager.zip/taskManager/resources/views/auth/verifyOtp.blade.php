@extends('layouts.fullpage')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-4">
            <h2>Verify OTP</h2>
            <form id="otp-verify-form" method="POST" action="{{ route('registerUser') }}">
                @csrf
                <input type="hidden" name="email" id="email" value="{{ $email }}">
                <div class="mb-3">
                    <label>OTP</label>
                    <input type="text" name="otp" class="form-control" value="{{ old('otp') }}" required>
                </div>
                <button type="submit" class="btn btn-primary w-100" id="send-otp">Register</button>
                <a href="{{ route('register') }}" class="">Use another email</a>
            </form>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {

            $("#otp-verify-form").validate({
                rules: {
                    email: {
                        required: true,
                        email: true
                    },
                    otp: {
                        required: true,
                        digits: true,
                        rangelength: [6, 6]
                    }
                },
                messages: {
                    email: {
                        required: "Please enter your email",
                        email: "Please enter a valid email address"
                    },
                    otp: {
                        required: "Please enter an OTP",
                        digits: "OTP must contain only numbers",
                        rangelength: "OTP must be exactly 6 digits long"
                    }
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });
    </script>
@endsection
