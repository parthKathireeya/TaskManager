@extends('layouts.app')

@section('content')
    <div class="container mt-4">
        <h2>Welcome to the Task Manager Dashboard</h2>
        <div class="row">
            <div class="col-md-3">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Total Tasks</div>
                    <div class="card-body">
                        <h5 class="card-title">{{ $totalTasks }}</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success mb-3">
                    <div class="card-header">Completed Tasks</div>
                    <div class="card-body">
                        <h5 class="card-title">{{ $completedTasks }}</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info mb-3">
                    <div class="card-header">In Progress</div>
                    <div class="card-body">
                        <h5 class="card-title">{{ $inProgressTasks }}</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-header">Pending Tasks</div>
                    <div class="card-body">
                        <h5 class="card-title">{{ $pendingTasks }}</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-danger mb-3">
                    <div class="card-header">Overdue Tasks</div>
                    <div class="card-body">
                        <h5 class="card-title">{{ $pastDueTasks }}</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
