<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name') }}</title>
    <link rel="stylesheet" href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/toastr/toastr.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/fontawesome/css/all.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/datatables/dataTables.bootstrap5.min.css') }}">
    <style>

    </style>
</head>

<body>
    <div class="sidebar">
        <h4 class="text-white text-center">Task Manager</h4>
        <a href="{{ route('dashboard') }}"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="{{ route('taskList') }}"><i class="fas fa-tasks"></i> Tasks</a>
    </div>
    <div class="content">
        <nav class="navbar navbar-custom">
            <span class="navbar-brand">Dashboard</span>
            <div>
                <button class="toggle-dark-mode" onclick="toggleDarkMode()">
                    <i id='mode-toggle' class="fas fa-moon"></i>
                </button>
                <div class="dropdown d-inline">
                    <button class="btn btn-link text-white dropdown-toggle" type="button" id="profileDropdown"
                        data-bs-toggle="dropdown">
                        {{ Auth::user()->name }}
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="#">Profile</a></li>
                        <li><a class="dropdown-item" href="{{ route('logout') }}">Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        @yield('content')
    </div>
    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('assets/toastr/toastr.min.js') }}"></script>
    <script src="{{ asset('assets/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/datatables/dataTables.bootstrap5.min.js') }}"></script>
    <script>
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
        };

        @if (session('success'))
            toastr.success("{{ session('success') }}");
        @endif

        @if (session('error'))
            toastr.error("{{ session('error') }}");
        @endif

        function toggleDarkMode() {
            let html = document.documentElement;
            let modeToggle = document.getElementById("mode-toggle");

            if (html.getAttribute("data-theme") === "dark") {
                html.setAttribute("data-theme", "light");
                modeToggle.classList.remove("fa-sun");
                modeToggle.classList.add("fa-moon");
                localStorage.setItem("darkMode", "false");
            } else {
                html.setAttribute("data-theme", "dark");
                modeToggle.classList.remove("fa-moon");
                modeToggle.classList.add("fa-sun");
                localStorage.setItem("darkMode", "true");
            }
        }

        if (localStorage.getItem("darkMode") === "true") {
            document.documentElement.setAttribute("data-theme", "dark");
            document.getElementById("mode-toggle").classList.remove("fa-moon");
            document.getElementById("mode-toggle").classList.add("fa-sun");
        }
    </script>
    @yield('scripts')
</body>

</html>
