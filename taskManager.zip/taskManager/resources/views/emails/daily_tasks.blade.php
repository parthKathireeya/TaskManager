<!DOCTYPE html>
<html>
<head>
    <title>Your To-Do Tasks</title>
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f8f9fa;">
    <table align="center" width="600" cellpadding="10" cellspacing="0" style="background-color: #ffffff; border-radius: 5px; box-shadow: 0px 0px 5px #ccc;">
        <tr>
            <td style="background-color: #007bff; color: white; text-align: center; font-size: 20px; padding: 10px; font-weight: bold;">
                Your To-Do Tasks for Today
            </td>
        </tr>
        <tr>
            <td style="padding: 15px;">
                <p>Dear {{ $user->name }},</p>
                <p>Here are your tasks for today ({{ \Carbon\Carbon::now()->format('d M, Y') }}):</p>
                <table width="100%" cellpadding="5" cellspacing="0" border="1" style="border-collapse: collapse; text-align: left;">
                    <tr style="background-color: #f2f2f2;">
                        <th style="padding: 8px;">Title</th>
                        <th style="padding: 8px;">Description</th>
                        <th style="padding: 8px;">Priority</th>
                        <th style="padding: 8px;">Status</th>
                        <th style="padding: 8px;">Due Date</th>
                    </tr>
                    @foreach ($tasks as $task)
                    <tr>
                        <td style="padding: 8px;">{{ $task->title }}</td>
                        <td style="padding: 8px;">{{ $task->description }}</td>
                        <td style="padding: 8px;">
                            <span style="background-color: #ffc107; color: black; padding: 5px 10px; border-radius: 3px;">
                                {{ $task->priority == 1 ? 'Low' : ($task->priority == 2 ? 'Medium' : 'High') }}
                            </span>
                        </td>
                        <td style="padding: 8px;">
                            <span style="background-color: #dc3545; color: white; padding: 5px 10px; border-radius: 3px;">
                                {{ $task->status == 3 ? 'Past Due' : 'Pending' }}
                            </span>
                        </td>
                        <td style="padding: 8px;">{{ \Carbon\Carbon::parse($task->due_date)->format('d M, Y') }}</td>
                    </tr>
                    @endforeach
                </table>
                <p>Make sure to complete your tasks on time!</p>
                <p>Best regards,<br><strong>Task Manager</strong></p>
            </td>
        </tr>
    </table>
</body>
</html>
