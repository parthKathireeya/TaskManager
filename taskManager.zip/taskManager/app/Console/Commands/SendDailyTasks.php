<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMail;
use App\Models\TaskModel;

class SendDailyTasks extends Command
{
    protected $signature = 'task:send-daily';

    protected $description = 'Send users their daily tasks every morning at 8:00 AM';

    public function handle()
    {
        $today = Carbon::today()->toDateString();

        User::chunk(50, function ($users) use ($today) {
            foreach ($users as $user) {
                $tasks = TaskModel::where('assign_to', $user->id)
                    ->whereDate('due_date', $today)
                    ->get();

                if ($tasks->isNotEmpty()) {

                    $emailContent = view('emails.daily_tasks', [
                        'tasks' => $tasks,
                        'user' => $user
                    ])->render();

                    Mail::to($user->email)->send(new SendMail(
                        'Your to-do tasks from TaskManager.', $emailContent
                    ));

                    $this->info("Email sent to {$user->email} with " . $tasks->count() . " task(s).");
                }
            }
        });
    }
}
