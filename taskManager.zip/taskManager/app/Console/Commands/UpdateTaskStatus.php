<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TaskModel;
use Carbon\Carbon;

class UpdateTaskStatus extends Command
{
    protected $signature = 'task:update-status';

    protected $description = 'Update task status to 3 if due_date is past';

    public function handle()
    {
        $today = Carbon::today();

        $updated = TaskModel::whereDate('due_date', '<', $today)
            ->where('status', '!=', 3)
            ->update(['status' => 3]);

        $this->info("{$updated} task(s) updated to status 3.");
    }
}
