<?php

namespace App\Http\Controllers;

use App\Models\CommentModel;
use App\Models\TaskModel;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Validator;

class TaskController extends Controller
{
    public function index(Request $request)
    {
        $status = [
            1 => ['text' => 'Pending', 'class' => 'badge bg-warning'],
            2 => ['text' => 'In Progress', 'class' => 'badge bg-primary'],
            3 => ['text' => 'Past Due', 'class' => 'badge bg-danger'],
            4 => ['text' => 'Completed', 'class' => 'badge bg-success'],
        ];

        $priority = [
            1 => ['text' => 'Low', 'class' => 'badge bg-secondary'],
            2 => ['text' => 'Medium', 'class' => 'badge bg-info'],
            3 => ['text' => 'High', 'class' => 'badge bg-danger'],
        ];

        $users = User::pluck('name', 'id')->toArray();

        if ($request->ajax()) {
            $tasks = TaskModel::query();

            if (auth()->user()->is_admin == 0) {
                $tasks->where('assign_to', auth()->user()->id);
            }

            return datatables()->of($tasks)
                ->addIndexColumn()
                ->addColumn('assigned_user', function ($row) use ($users) {
                    return $users[$row->assign_to] ?? '';
                })
                ->addColumn('title', function ($row){
                    $title = $row->title;

                    if (auth()->user()->is_admin == 0 && $row->created_by != auth()->user()->id){
                        $title .= '<br><span class="text-primary">Assigned to you</span>';
                    }
                    return $title;
                })
                ->addColumn('status', function ($row) use ($status) {
                    return "<span class='{$status[$row->status]['class']}'>{$status[$row->status]['text']}</span>";
                })
                ->addColumn('priority', function ($row) use ($priority) {
                    return "<span class='{$priority[$row->priority]['class']}'>{$priority[$row->priority]['text']}</span>";
                })
                ->addColumn('action', function ($row) {
                    $actionButtons = '
                        <a href="javascript:void(0);" class="mb-1 btn btn-sm btn-primary comment-btn" onclick="seeComments(' . $row->id . ')">
                            <i class="fas fa-comments"></i> Comments
                        </a>
                        <a href="javascript:void(0);" class="mb-1 btn btn-sm btn-primary edit-btn" onclick="addEditTask(' . $row->id . ')">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="javascript:void(0);" class="mb-1 btn btn-sm btn-danger delete-btn" onclick="deleteTask(' . $row->id . ')">
                            <i class="fas fa-trash-alt"></i> Delete
                        </a>
                    ';

                    if (!in_array($row->status, array(3, 1))) {
                        $actionButtons .= '
                            <a href="javascript:void(0);" class="mb-1 btn btn-sm btn-warning" onclick="changeStatus(' . $row->id . ', 1)">
                                <i class="fas fa-check-circle"></i> Pending
                            </a>
                        ';
                    }

                    if (!in_array($row->status, array(3, 2))) {
                        $actionButtons .= '
                            <a href="javascript:void(0);" class="mb-1 btn btn-sm btn-info" onclick="changeStatus(' . $row->id . ', 2)">
                                <i class="fas fa-spinner"></i> In Progress
                            </a>
                        ';
                    }

                    if (!in_array($row->status, array(3, 4))) {
                        $actionButtons .= '
                            <a href="javascript:void(0);" class="mb-1 btn btn-sm btn-success" onclick="changeStatus(' . $row->id . ', 4)">
                                <i class="fas fa-check-double"></i> Complete
                            </a>
                        ';
                    }

                    return $actionButtons;
                })
                ->rawColumns(['assigned_user', 'title', 'status', 'priority', 'action'])
                ->make(true);
        }

        return view('tasks.list');
    }

    public function taskCrud($taskId)
    {

        $task = null;

        $users = User::pluck('name', 'id')->toArray();

        if (is_numeric($taskId) && $taskId > 0) {
            $task = TaskModel::find($taskId);
        }

        return response()->json(view('tasks.crud', compact('task', 'users'))->render());
    }

    public function createTask(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:255',
            'description' => 'required|string|max:500',
            'due_date' => 'required|date',
            'priority' => 'required|integer|between:1,3',
        ]);

        try {
            if ($validator->fails()) {
                throw new Exception($validator->errors()->first());
            }

            $task = new TaskModel();
            $task->title = $request->input('title');
            $task->description = $request->input('description');
            $task->due_date = Carbon::parse($request->input('due_date'))->format('Y-m-d');
            $task->priority = $request->input('priority');
            $task->assign_to = auth()->user()->id;
            $task->created_by = auth()->user()->id;

            if (auth()->user()->is_admin == 1) {
                $task->assign_to = $request->input('assign_to') ?? auth()->user()->id;
            }

            $task->save();

            return redirect()->route('taskList')->with('success', 'Task created successfully.');
        } catch (Exception $e) {
            return redirect()->route('taskList')->with('error', $e->getMessage());
        }
    }

    public function updateTask(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => 'required|integer|min:1',
            'title' => 'required|string|max:255',
            'description' => 'required|string|max:500',
            'due_date' => 'required|date',
            'priority' => 'required|integer|between:1,3',
        ]);

        try {
            if ($validator->fails()) {
                throw new Exception($validator->errors()->first());
            }

            $task = TaskModel::find($request->input('id'));
            $task->title = $request->input('title');
            $task->description = $request->input('description');
            $task->due_date = Carbon::parse($request->input('due_date'))->format('Y-m-d');
            $task->priority = $request->input('priority');
            $task->assign_to = auth()->user()->id;

            if (auth()->user()->is_admin == 1) {
                $task->assign_to = $request->input('assign_to') ?? auth()->user()->id;
            }

            $newDueDate = Carbon::parse($request->input('due_date'));
            if ($newDueDate->gt(now()) && $task->status == 3) {
                $task->status = 1;
            }

            $task->save();

            return redirect()->route('taskList')->with('success', 'Task updated successfully.');
        } catch (Exception $e) {
            return redirect()->route('taskList')->with('error', $e->getMessage());
        }
    }

    public function deleteTask($taskId)
    {
        try {
            $task = TaskModel::find($taskId);
            if (!$task) {
                throw new Exception('Task not found.');
            }

            $task->delete();

            $comments = CommentModel::where('task_id', $taskId)->delete();

            return response()->json(['success' => 'Task deleted successfully.']);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function changeTaskStatus(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'task_id' => 'required|integer|min:1',
            'status' => 'required|integer|between:1,4',
        ]);

        try {
            if ($validator->fails()) {
                throw new Exception($validator->errors()->first());
            }

            $task = TaskModel::find($request->input('task_id'));
            if (!$task) {
                throw new Exception('Task not found.');
            }

            $task->status = $request->input('status');
            $task->save();

            return response()->json(['success' => 'Task status updated successfully.']);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function taskComments($taskId)
    {
        $comments = CommentModel::join('users', 'comments.created_by', '=', 'users.id')
            ->where('comments.task_id', $taskId)
            ->select('comments.*', 'users.name as user_name')
            ->get();

        return response()->json(view('tasks.comments', compact('comments', 'taskId'))->render());
    }

    public function addTaskComments(Request $request, $taskId)
    {
        $validator = Validator::make($request->all(), [
            'comment' => 'required|string|max:500',
        ]);

        try {
            if ($validator->fails()) {
                throw new Exception($validator->errors()->first());
            }

            $comment = new CommentModel();
            $comment->task_id = $taskId;
            $comment->created_by = auth()->user()->id;
            $comment->comment = $request->input('comment');
            $comment->save();

            return response()->json(['success' => 'Comment added successfully.']);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
