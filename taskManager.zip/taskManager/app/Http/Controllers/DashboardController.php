<?php

namespace App\Http\Controllers;

use App\Models\TaskModel;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {

        $tasks = TaskModel::all();

        if(auth()->user()->is_admin == 0) {
            $tasks = $tasks->where('assign_to', auth()->user()->id);
        }

        $totalTasks = $tasks->count();
        $pendingTasks = $tasks->where('status', 1)->count();
        $inProgressTasks = $tasks->where('status', 2)->count();
        $pastDueTasks = $tasks->where('status', 3)->count();
        $completedTasks = $tasks->where('status', 4)->count();

        return view('dashboard.index', [
            'totalTasks' => $totalTasks,
            'pendingTasks' => $pendingTasks,
            'inProgressTasks' => $inProgressTasks,
            'pastDueTasks' => $pastDueTasks,
            'completedTasks' => $completedTasks,
        ]);
    }
}
