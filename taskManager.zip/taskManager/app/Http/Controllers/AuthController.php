<?php

namespace App\Http\Controllers;

use App\Mail\SendMail;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class AuthController extends Controller
{
    public function register(Request $request)
    {

        if (Auth::check()) {
            return redirect()->route('dashboard')->with('success', 'You are already logged in');
        }

        return view('auth.register');
    }

    public function otpVerify(Request $request)
    {
        if (Auth::check()) {
            return redirect()->route('dashboard')->with('success', 'You are already logged in');
        }

        try {
            if (!$request->session()->has($request->email)) {
                throw new Exception('Session expired. Please try again.');
            }

            $email = $request->email;

            return view('auth.verifyOtp', compact('email'));
        } catch (Exception $e) {
            return redirect()->route('register')->with('error', $e->getMessage());
        }
    }

    public function sendOtp(Request $request)
    {
        $request->validate([
            'name' => 'required|max:70',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8|max:15|confirmed',
        ]);

        try {

            $otp = random_int(100000, 999999);
            $validTill = now()->addMinutes(10);

            Session::put($request->email, [
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
                'otp' => $otp,
                'valid_till' => $validTill
            ]);

            $content = '<p>Your OTP is: <strong>' . $otp . '</strong> for registration in TaskManager and it is valid till next 10 minutes.</p>';


            Mail::to($request->email)->send(new SendMail(
                'OTP for registration in TaskManager',
                $content
            ));

            return redirect()->route('otpVerify', [$request->email])->with('success', 'OTP sent to your email. Please check your inbox.');
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage())->withInput();
        }
    }

    public function emailAvailable(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'email' => 'required|email|unique:users,email'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => $validator->errors()->first('email')
            ]);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Email is available'
        ]);
    }

    public function registerUser(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'otp' => 'required|digits:6'
            ]);

            if ($validator->fails()) {
                throw new Exception($validator->errors()->first());
            }

            if (!$request->session()->has($request->email)) {
                throw new Exception('Session expired. Please try again.');
            }

            $sessionData = $request->session()->get($request->email);

            if ($sessionData['otp'] != $request->otp) {
                throw new Exception('Invalid OTP. Please try again.');
            }

            $user = new User();
            $user->name = $sessionData['name'];
            $user->email = $sessionData['email'];
            $user->password = Hash::make($sessionData['password']);
            $user->save();

            $request->session()->forget($request->email);

            if (Auth::attempt(['email' => $sessionData['email'], 'password' => $sessionData['password']])) {
                return redirect()->route('dashboard')->with('success', 'Registration successful. Welcome to TaskManager!');
            } else {
                throw new Exception('Login failed. Please try again.');
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage())->withInput();
        }
    }

    public function login(Request $request)
    {
        if (Auth::check()) {
            return redirect()->route('dashboard')->with('success', 'You are already logged in');
        }

        return view('auth.login');
    }

    public function loginUser(Request $request){
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|min:8|max:15',
            ]);

            if ($validator->fails()) {
                throw new Exception($validator->errors()->first());
            }

            if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
                return redirect()->route('dashboard')->with('success', 'Welcome to TaskManager!');
            } else {
                throw new Exception('Login failed. Please try again.');
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage())->withInput();
        }
    }

    public function logout(Request $request)
    {
        Auth::logout();
        return redirect()->route('login')->with('success', 'Logged out successfully.');
    }

}
