<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <h2>Register</h2>
            <form id="register-form" method="POST" action="<?php echo e(route('sendOtp')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required maxlength="70">
                </div>
                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                </div>
                <div class="mb-3">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" required pattern="[A-Za-z0-9]{8,15}">
                </div>
                <div class="mb-3">
                    <label>Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control" value="<?php echo e(old('password_confirmation')); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary w-100" id="send-otp">Send OTP</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            });

            $("#register-form").validate({
                rules: {
                    name: {
                        required: true,
                        maxlength: 70
                    },
                    email: {
                        required: true,
                        email: true,
                        remote: {
                            url: '<?php echo e(route('emailAvailable')); ?>',
                            type: 'POST',
                            data: {
                                email: function() {
                                    return $("input[name='email']").val();
                                }
                            },
                            dataFilter: function(data) {
                                var json = JSON.parse(data);
                                if (json.status === 'error') {
                                    return false;
                                }
                                return true;
                            }
                        }
                    },
                    password: {
                        required: true,
                        minlength: 8,
                        maxlength: 15,
                        customPattern: true
                    },
                    password_confirmation: {
                        required: true,
                        equalTo: "[name='password']"
                    }
                },
                messages: {
                    name: {
                        required: "Please enter your name",
                        maxlength: "Name cannot be more than 70 characters"
                    },
                    email: {
                        required: "Please enter a valid email address",
                        email: "Please enter a valid email address",
                        remote: "This email is already taken"
                    },
                    password: {
                        required: "Please enter a password",
                        minlength: "Password must be between 8 to 15 characters",
                        maxlength: "Password cannot be more than 15 characters",
                        customPattern: "Password can only contain letters and numbers"
                    },
                    password_confirmation: {
                        required: "Please confirm your password",
                        equalTo: "Passwords do not match"
                    }
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });

            $.validator.addMethod("customPattern", function(value, element) {
                return this.optional(element) || /^[A-Za-z0-9]+$/.test(value);
            }, "Password can only contain letters and numbers");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fullpage', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManager\resources\views\auth\register.blade.php ENDPATH**/ ?>