<!DOCTYPE html>
<html>

<head>
    <title>Today's To-Do Tasks</title>
    <link href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>

<body style="font-family: Arial, sans-serif; background-color: #f8f9fa; padding: 20px;">

    <div class="container">
        <div class="card border-primary">
            <div class="card-header bg-primary text-white text-center">
                <h2>Your To-Do Tasks for Today</h2>
            </div>
            <div class="card-body">
                <p>Dear <?php echo e($user->name); ?>,</p>
                <p>Here are your tasks for today (<?php echo e(date('d M, Y')); ?>):</p>

                <table class="table table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th>Due Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($task->title); ?></td>
                                <td><?php echo e($task->description); ?></td>
                                <td>
                                    <?php if($task->priority == 1): ?>
                                        <span class="badge bg-success">Low</span>
                                    <?php elseif($task->priority == 2): ?>
                                        <span class="badge bg-warning">Medium</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">High</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($task->status == 1): ?>
                                        <span class="badge bg-secondary">Pending</span>
                                    <?php elseif($task->status == 2): ?>
                                        <span class="badge bg-info">In Progress</span>
                                    <?php elseif($task->status == 3): ?>
                                        <span class="badge bg-danger">Past Due</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Completed</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date('d M, Y', strtotime($task->due_date))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <p>Make sure to complete your tasks on time!</p>
                <p>Best regards,<br><strong>Task Manager</strong></p>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\taskManager\resources\views\emails\daily_tasks.blade.php ENDPATH**/ ?>