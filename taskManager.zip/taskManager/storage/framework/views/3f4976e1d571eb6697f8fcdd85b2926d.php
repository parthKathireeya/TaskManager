<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <h2>Log in</h2>
            <form id="login-form" method="POST" action="<?php echo e(route('loginUser')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                </div>
                <div class="mb-3">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" required pattern="[A-Za-z0-9]{8,15}">
                </div>
                <button type="submit" class="btn btn-primary w-100" id="log-in">Log in</button>
                <a href="<?php echo e(route('register')); ?>" class="">Register</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {

            $("#login-form").validate({
                rules: {
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        minlength: 8,
                        maxlength: 15,
                        customPattern: true
                    }
                },
                messages: {
                    email: {
                        required: "Please enter a valid email address",
                        email: "Please enter a valid email address"
                    },
                    password: {
                        required: "Please enter a password",
                        minlength: "Password must be between 8 to 15 characters",
                        maxlength: "Password cannot be more than 15 characters",
                        customPattern: "Password can only contain letters and numbers"
                    }
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });

            $.validator.addMethod("customPattern", function(value, element) {
                return this.optional(element) || /^[A-Za-z0-9]+$/.test(value);
            }, "Password can only contain letters and numbers");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fullpage', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManager\resources\views/auth/login.blade.php ENDPATH**/ ?>