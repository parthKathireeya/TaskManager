<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2>Welcome to the Task Manager Dashboard</h2>
        <div class="row">
            <div class="col-md-3">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Total Tasks</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($totalTasks); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success mb-3">
                    <div class="card-header">Completed Tasks</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($completedTasks); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info mb-3">
                    <div class="card-header">In Progress</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($inProgressTasks); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-header">Pending Tasks</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($pendingTasks); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-danger mb-3">
                    <div class="card-header">Overdue Tasks</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($pastDueTasks); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManager\resources\views\dashboard\index.blade.php ENDPATH**/ ?>