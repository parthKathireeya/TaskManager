<div class="modal fade" id="taskCommentsModal" tabindex="-1" aria-labelledby="taskCommentsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="taskCommentsModalLabel">Task Comments</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="chat-box p-3" style="max-height: 300px; overflow-y: auto;">


                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(auth()->user()->id == $comments->created_by): ?>
                            <div class="d-flex justify-content-end mb-2">
                                <div class="p-2 bg-primary text-white rounded w-75">
                                    <strong>You</strong>
                                    <p class="mb-0"><?php echo e($comments->comment); ?></p>
                                    <small
                                        class="text-white-50"><?php echo e(date('h:i A d-m-Y', strtotime($comments->created_at))); ?></small>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="d-flex justify-content-start mb-2">
                                <div class="p-2 bg-light rounded w-75">
                                    <strong><?php echo e($comments->user_name); ?></strong>
                                    <p class="mb-0">T<?php echo e($comments->comment); ?></p>
                                    <small
                                        class="text-muted"><?php echo e(date('h:i A d-m-Y', strtotime($comments->created_at))); ?></small>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="modal-footer">
                <input style="max-width: 80%" type="text" class="form-control" id="commentInput"
                    placeholder="Type your comment...">
                <button class="btn btn-primary" onclick="addComment(<?php echo e($taskId); ?>)" id="sendComment">Send</button>
            </div>
        </div>
    </div>
</div>
<script>
    function addComment(taskId) {
        let comment = $('#commentInput').val();
        if (comment.trim() === '') {
            alert('Please enter a comment.');
            return;
        }

        $.ajax({
            url: `add-task-comments/${taskId}`,
            type: 'POST',
            data: {
                comment: comment,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                $('#taskCommentsModal').modal('hide');
                $('#commentInput').val('');
                location.reload();
            },
            error: function(xhr, status, error) {
                toastr.error(xhr.responseText);
            }
        });
    }
</script>
<?php /**PATH C:\xampp\htdocs\taskManager\resources\views\tasks\comments.blade.php ENDPATH**/ ?>