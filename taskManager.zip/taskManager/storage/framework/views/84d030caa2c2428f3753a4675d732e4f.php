<div class="modal fade" id="taskModal" tabindex="-1" aria-labelledby="taskModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="taskModalLabel">Add Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="taskForm" method="POST"
                    action="<?php echo e(@$task->id > 0 ? route('updateTask') : route('createTask')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="taskId" value="<?php echo e(@$task->id ?? 0); ?>">

                    <?php if(auth()->user() && auth()->user()->is_admin): ?>
                        <div class="mb-3">
                            <label class="form-label">Assign To</label>
                            <select class="form-control" name="assign_to" id="assign_to">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userId => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($userId); ?>"
                                        <?php echo e((isset($task) && $task->assign_to == $userId) || (!isset($task->assign_to) && auth()->user()->id == $userId) ? 'selected' : ''); ?>>
                                        <?php echo e($user); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>


                    <div class="mb-3">
                        <label class="form-label">Task Title</label>
                        <input type="text" value="<?php echo e(@$task->title); ?>" class="form-control" name="title" id="title" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="description" required><?php echo e(@$task->description); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Due Date</label>
                        <input type="date" value="<?php echo e(@$task->due_date); ?>" class="form-control" name="due_date" id="due_date" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Priority</label>
                        <select class="form-control" name="priority" id="priority">
                            <option <?php echo e((isset($task) && $task->priority == 1) ? 'selected' : ''); ?> value="1">Low</option>
                            <option <?php echo e((isset($task) && $task->priority == 2) || (!isset($task->priority)) ? 'selected' : ''); ?> value="2">Medium</option>
                            <option <?php echo e((isset($task) && $task->priority == 3) ? 'selected' : ''); ?> value="3">High</option>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Task</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {

        $("#taskForm").validate({
            rules: {
                title: {
                    required: true,
                    maxlength: 255
                },
                description: {
                    required: true,
                    maxlength: 500
                },
                due_date: {
                    required: true,
                    date: true,
                    min: new Date().toISOString().split("T")[0]
                }
            },
            messages: {
                title: {
                    required: "Task title is required.",
                    maxlength: "Title cannot exceed 255 characters."
                },
                description: {
                    required: "Please provide a task description.",
                    maxlength: "Description cannot exceed 500 characters."
                },
                due_date: {
                    required: "Please select a due date.",
                    date: "Enter a valid date.",
                    min: "Due date cannot be in the past."
                }
            },
            submitHandler: function(form) {
                form.submit();
            }
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\taskManager\resources\views\tasks\crud.blade.php ENDPATH**/ ?>