<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-4">
            <h2>Verify OTP</h2>
            <form id="otp-verify-form" method="POST" action="<?php echo e(route('registerUser')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="email" id="email" value="<?php echo e($email); ?>">
                <div class="mb-3">
                    <label>OTP</label>
                    <input type="text" name="otp" class="form-control" value="<?php echo e(old('otp')); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary w-100" id="send-otp">Send OTP</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {

            $("#otp-verify-form").validate({
                rules: {
                    email: {
                        required: true,
                        email: true
                    },
                    otp: {
                        required: true,
                        digits: true,
                        rangelength: [6, 6]
                    }
                },
                messages: {
                    email: {
                        required: "Please enter your email",
                        email: "Please enter a valid email address"
                    },
                    otp: {
                        required: "Please enter an OTP",
                        digits: "OTP must contain only numbers",
                        rangelength: "OTP must be exactly 6 digits long"
                    }
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fullpage', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManager\resources\views\auth\verifyOtp.blade.php ENDPATH**/ ?>