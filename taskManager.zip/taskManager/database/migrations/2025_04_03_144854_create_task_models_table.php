<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->string('title', 255)->nullable();
            $table->text('description')->nullable();
            $table->date('due_date')->nullable();
            $table->tinyInteger('priority')->default(2)->comment('1 => Low, 2 => Medium, 3 => High');
            $table->tinyInteger('status')->default(1)->comment('1 => Pending, 2 => In Progress, 3 => Past Due, 4 => Completed');
            $table->unsignedInteger('created_by')->default(0);
            $table->unsignedInteger('assign_to')->default(0);
            $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->timestamp('updated_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tasks');
    }
};
